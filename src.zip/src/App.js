
import './App.css';
import Signup from './Component/Signup';
import Update from './Component/Update';
import Welcome from './Component/Welcome';
import Welcomeadmin from './Component/Welcomeadmin';
import Bookappointment from './Component/Bookappointment';
import Updateavailability from './Component/Updateavailability';
import Addavailability from './Component/Addavailability';
import Signin from './Component/Signin';
import ReschedualAppointment from './Component/ReschedualAppointment';
import ProfilePage from './Component/ProfilePage';
import CancelAppointment from './Component/CancelAppointment';
import AppointmentStatus from './Component/AppointmentStatus';
import AppointmentBooking from './Component/AppointmentBooking';
import AllBooking from './Component/AllBooking';
function App() {
  return (
    <div className="App">
    
      
    <Addavailability/>
    </div>
  );
}

export default App;